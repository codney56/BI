package com.yupi.springbootinit.mapper;

import com.yupi.springbootinit.model.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.yupi.springbootinit.model.entity.User
 */
public interface UserMapper extends BaseMapper<User> {

}




